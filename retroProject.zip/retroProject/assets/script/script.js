// Globale Header
// jQuery(document).ready(($) => {
window.addEventListener("load", () => {
    document.getElementById("header").innerHTML = `<header class="site-header">
        <div class="site-header__container">
    
            <div class="logo">
                <a class="logo__link" href="index.html">Max Factor'x</a>
            </div>
            <button id="menu-toggle" class="menu-toggle"><i class="fa-solid fa-bars"></i></button>
            <nav class="main-navigation">
                <ul class="menu-items">
                    <li class="menu-item"><a href="index.html" class="menu-item__link">Home</a></li>
                    <li class="menu-item"><a href="about.html" class="menu-item__link">About</a></li>
                    <li class="menu-item"><a href="product.html" class="menu-item__link">product</a></li>
                    <li class="menu-item"><a href="contact.html" class="menu-item__link">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>`;

    // Globale Footer
    document.getElementById("footer").innerHTML = `<footer>
    <div class="container text-center">
        <p>Copyright @ 2023 Max Factor'x. All Rights Reserved.</p>
    </div>
</footer>`;
});

// });

// NavBar
setTimeout(() => {
    const menuToggle = document.getElementById("menu-toggle");
    const mainNavigation = document.querySelector(".main-navigation");
    const menuItems = document.querySelectorAll(".menu-item__link");

    menuToggle.addEventListener("click", () => {
        mainNavigation.classList.toggle("show-menu");
    });

    // Highlight the active menu item
    menuItems.forEach((item) => {
        if (item.href === window.location.href) {
            item.classList.add("active");
        }
    });
    window.onscroll = function() {
        myFunction();
    };
    var header = document.getElementById("header");
    var sticky = header.offsetTop;

    var myFunction = () => {
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
        } else {
            header.classList.remove("sticky");
        }
    };
}, 2000);